package com.factory;

import com.config.Configuration;
import com.session.DefaultSqlSession;
import com.session.SqlSession;

/**
 * @author aleng
 * @version 1.0.0
 * @className DefaultSqlSessionFactory
 * @description TODO
 * @createTime 2020年04月24日 11:16:00
 */
public class DefaultSqlSessionFactory implements SqlSessionFactory {

  private Configuration configuration;

  public DefaultSqlSessionFactory(Configuration configuration) {
    this.configuration = configuration;
  }

  /**
   * @title openSession
   * @description 11:22
   * @author aleng
   * @updateTime 2020/4/24
   * @return com.session.SqlSession
   */
  public SqlSession openSession() {
    return new DefaultSqlSession(configuration);
  }
}
