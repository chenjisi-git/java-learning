package com.factory;

import com.session.SqlSession;

/**
 * @author aleng
 * @version 1.0.0
 * @className factory
 * @description TODO
 * @createTime 2020年04月23日 14:58:00
 */
public interface SqlSessionFactory {
  /**
   * @title openSession
   * @description 11:22
   * @author aleng
   * @updateTime 2020/4/24
   * @return com.session.SqlSession
   */
  SqlSession openSession();
}
