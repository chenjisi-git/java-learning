package com.builder;

import com.config.Configuration;
import com.factory.DefaultSqlSessionFactory;
import com.factory.SqlSessionFactory;
import org.dom4j.DocumentException;

import java.beans.PropertyVetoException;
import java.io.InputStream;

/**
 * @author aleng
 * @version 1.0.0
 * @className SqlSessionFactoryBuilder
 * @description TODO
 * @createTime 2020年04月23日 14:54:00
 */
public class SqlSessionFactoryBuilder {

  /*jdbc配置*/
  private Configuration configuration = new Configuration();;

  public SqlSessionFactoryBuilder() {}

  public SqlSessionFactory create(InputStream inputStream)
      throws DocumentException, PropertyVetoException, ClassNotFoundException {
    // 解析配置文件，封装Configuration
    configuration = new XmlConfigBuilder(configuration).parseConfiguration(inputStream);
    // 返回SqlSessionFactory
    return new DefaultSqlSessionFactory(configuration);
  }
}
