package com.builder;

import com.config.Configuration;
import com.io.Resource;
import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.beans.PropertyVetoException;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;

/**
 * @author aleng
 * @version 1.0.0
 * @className XmlConfigBuilder
 * @description TODO
 * @createTime 2020年04月24日 12:04:00
 */
public class XmlConfigBuilder {
  /*jdbc配置*/
  private Configuration configuration;

  public XmlConfigBuilder(Configuration configuration) {
    this.configuration = configuration;
  }

  /**
   * @title parseConfiguration
   * @description 把输入流里面的jdbc配置信息，解析jdbc配置对象
   * @author aleng
   * @updateTime 2020/4/24
   * @param inputStream
   * @return com.config.Configuration
   */
  public Configuration parseConfiguration(InputStream inputStream)
      throws DocumentException, PropertyVetoException, ClassNotFoundException {
    Document document = new SAXReader().read(inputStream);
    // configuation
    Element rootElement = document.getRootElement();
    List<Element> propertyElements = rootElement.selectNodes("//property");
    Properties properties = new Properties();
    for (Element propertyElement : propertyElements) {
      String name = propertyElement.attributeValue("name");
      String value = propertyElement.attributeValue("value");
      properties.setProperty(name, value);
    }
    ComboPooledDataSource comboPooledDataSource = new ComboPooledDataSource();
    comboPooledDataSource.setDriverClass(properties.getProperty("driverClass"));
    comboPooledDataSource.setJdbcUrl(properties.getProperty("url"));
    comboPooledDataSource.setUser(properties.getProperty("username"));
    comboPooledDataSource.setPassword(properties.getProperty("password"));
    configuration.setDataSource(comboPooledDataSource);
    List<Element> mapperElements = rootElement.selectNodes("//mapper");
    XMLMapperBuilder xmlMapperBuilder = new XMLMapperBuilder(configuration);
    for (Element mapperElement : mapperElements) {
      String mapperPath = mapperElement.attributeValue("resource");
      InputStream resourceAsSteam = Resource.getResourceAsStream(mapperPath);
      xmlMapperBuilder.parse(resourceAsSteam);
    }
    return configuration;
  }
}
