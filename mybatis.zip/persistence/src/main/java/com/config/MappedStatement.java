package com.config;

import com.constant.OperationMethodEnum;

/**
 * @author aleng
 * @version 1.0.0
 * @className Statement
 * @description 对应mybatis xml文件里面的一个sql单元
 * @createTime 2020年04月23日 14:42:00
 */
public class MappedStatement {

  private String id;
  private Class<?> parameterType;
  private Class<?> resultType;
  private String sql;
  private OperationMethodEnum method;

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getSql() {
    return sql;
  }

  public void setSql(String sql) {
    this.sql = sql;
  }

  public Class<?> getParameterType() {
    return parameterType;
  }

  public void setParameterType(Class<?> parameterType) {
    this.parameterType = parameterType;
  }

  public Class<?> getResultType() {
    return resultType;
  }

  public void setResultType(Class<?> resultType) {
    this.resultType = resultType;
  }

  public OperationMethodEnum getMethod() {
    return method;
  }

  public void setMethod(OperationMethodEnum method) {
    this.method = method;
  }

  @Override
  public String toString() {
    return "MappedStatement{"
        + "id='"
        + id
        + '\''
        + ", parameterType="
        + parameterType
        + ", resultType="
        + resultType
        + ", sql='"
        + sql
        + '\''
        + ", method="
        + method
        + '}';
  }
}
