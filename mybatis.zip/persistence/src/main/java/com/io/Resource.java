package com.io;

import java.io.InputStream;

/**
 * @author aleng
 * @version 1.0.0
 * @className Resource
 * @description TODO
 * @createTime 2020年04月23日 14:16:00
 */
public class Resource {

  public static InputStream getResourceAsStream(String path) {
    return Resource.class.getClassLoader().getResourceAsStream(path);
  }
}
