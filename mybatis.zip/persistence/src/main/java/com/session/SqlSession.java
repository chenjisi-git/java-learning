package com.session;

import java.util.List;

/**
 * @author aleng
 * @version 1.0.0
 * @className SqlSession
 * @description TODO
 * @createTime 2020年04月23日 14:58:00
 */
public interface SqlSession {

  <E> List<E> selectList(String statementId, Object... params) throws Exception;

  <T> T selectOne(String statementId, Object... params) throws Exception;

  void delete(String statementId, Object... params) throws Exception;

  void insert(String statementId, Object... params) throws Exception;

  void update(String statementId, Object... params) throws Exception;

  <T> T getMappper(Class<?> mapperClass);

  void close();
}
