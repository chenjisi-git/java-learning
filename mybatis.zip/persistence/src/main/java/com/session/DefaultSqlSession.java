package com.session;

import com.config.Configuration;
import com.config.MappedStatement;
import com.executor.Executor;
import com.executor.SimpleExecutor;

import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author aleng
 * @version 1.0.0
 * @className DefaultSqlSession
 * @description TODO
 * @createTime 2020年04月24日 17:52:00
 */
public class DefaultSqlSession implements SqlSession {

  private Configuration configuration;

  private Executor executor = new SimpleExecutor();

  public DefaultSqlSession(Configuration configuration) {
    this.configuration = configuration;
  }

  public <E> List<E> selectList(String statementId, Object... param) throws Exception {
    return executor.query(configuration, configuration.getStatementMap().get(statementId), param);
  }

  public <T> T selectOne(String statementId, Object... param) throws Exception {
    List<Object> objects = selectList(statementId, param);
    if (null == objects || objects.size() == 0) {
      return null;
    } else if (objects.size() == 1) {
      return (T) objects.get(0);
    } else {
      throw new RuntimeException("返回结果过多");
    }
  }

  @Override
  public void delete(String statementId, Object... params) throws Exception {
    executor.delete(configuration, configuration.getStatementMap().get(statementId), params);
  }

  @Override
  public void insert(String statementId, Object... params) throws Exception {
    executor.insert(configuration, configuration.getStatementMap().get(statementId), params);
  }

  @Override
  public void update(String statementId, Object... params) throws Exception {
    executor.insert(configuration, configuration.getStatementMap().get(statementId), params);
  }

  public <T> T getMappper(Class<?> mapperClass) {

    T o =
        (T)
            Proxy.newProxyInstance(
                mapperClass.getClassLoader(),
                new Class[] {mapperClass},
                new InvocationHandler() {
                  @Override
                  public Object invoke(Object proxy, Method method, Object[] args)
                      throws Throwable {
                    // selectOne
                    String methodName = method.getName();
                    // className:namespace
                    String className = method.getDeclaringClass().getName();
                    // statementid
                    String key = className + "." + methodName;
                    MappedStatement mappedStatement = configuration.getStatementMap().get(key);
                    Type genericReturnType = method.getGenericReturnType();
                    ArrayList arrayList = new ArrayList();
                    switch (mappedStatement.getMethod()) {
                      case DELETE:
                        handleDelete(key, args);
                        break;
                      case INSERT:
                        handleInsert(key, args);
                        break;
                      case SELECT:
                        return handleSelect(genericReturnType, key, args);
                      case UPDATE:
                        handleUpdate(key, args);
                        break;
                      default:
                        throw new RuntimeException("xmlMapper请求方法不正确");
                    }
                    return null;
                    //                    if (genericReturnType instanceof ParameterizedType) {
                    //                      return selectList(key, args);
                    //                    }
                    //                    return selectOne(key, args);
                  }
                });
    return o;
  }

  // 处理查询请求
  private Object handleSelect(Type genericReturnType, String statementId, Object... param)
      throws Exception {
    if (genericReturnType instanceof ParameterizedType) {
      return selectList(statementId, param);
    }
    return selectOne(statementId, param);
  }

  // 处理新增请求
  private void handleInsert(String statementId, Object... params) throws Exception {
    insert(statementId, params);
  }

  // 处理删除请求
  private void handleDelete(String statementId, Object... params) throws Exception {
    delete(statementId, params);
  }

  // 处理修改请求
  private void handleUpdate(String statementId, Object... params) throws Exception {
    update(statementId, params);
  }

  public void close() {}
}
