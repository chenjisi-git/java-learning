package com.executor;

import com.config.Configuration;
import com.config.MappedStatement;
import com.util.BoundSql;
import com.util.GenericTokenParser;
import com.util.ParameterMapping;
import com.util.ParameterMappingTokenHandler;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author aleng
 * @version 1.0.0
 * @className SimpleExecutor
 * @description TODO
 * @createTime 2020年04月24日 17:59:00
 */
public class SimpleExecutor implements Executor {

  private Connection connection = null;

  public <E> List<E> query(
      Configuration configuration, MappedStatement mappedStatement, Object[] param)
      throws SQLException, NoSuchFieldException, IllegalAccessException, InstantiationException,
          InvocationTargetException, IntrospectionException {
    // 获取连接
    connection = configuration.getDataSource().getConnection();
    // 获取sql  select * from user where id = #{id} and username = #{username}
    String sql = mappedStatement.getSql();
    // 解析sql把 #{} 这种标记通过反射，把指定参数值放到指定？位置
    BoundSql boundsql = getBoundSql(sql);
    // 解析后的sql select * from user where id = ? and username = ?
    String resultSql = boundsql.getSqlText();
    // 获取传入的参数类型
    Class<?> paramterType = mappedStatement.getParameterType();
    List<ParameterMapping> parameterMappingList = boundsql.getParameterMappingList();
    PreparedStatement preparedStatement = connection.prepareStatement(resultSql);
    for (int i = 0; i < parameterMappingList.size(); i++) {
      ParameterMapping parameterMapping = parameterMappingList.get(i);
      String name = parameterMapping.getContent();
      Field field = paramterType.getDeclaredField(name);
      field.setAccessible(true);
      // 获取参数值
      Object paramVal = field.get(param[0]);
      preparedStatement.setObject(i + 1, paramVal);
    }
    ResultSet resultSet = preparedStatement.executeQuery();
    Class<?> resultType = mappedStatement.getResultType();
    ArrayList<E> results = new ArrayList<E>();
    while (resultSet.next()) {
      ResultSetMetaData metaData = resultSet.getMetaData();
      E o = (E) resultType.newInstance();
      int columnCount = metaData.getColumnCount();
      for (int i = 1; i <= columnCount; i++) {
        String columnName = metaData.getColumnName(i);
        Object value = resultSet.getObject(columnName);
        PropertyDescriptor propertyDescriptor = new PropertyDescriptor(columnName, resultType);
        Method writeMethod = propertyDescriptor.getWriteMethod();
        writeMethod.invoke(o, value);
      }
      results.add(o);
    }
    return results;
  }

  public void delete(Configuration configuration, MappedStatement mappedStatement, Object[] param)
      throws Exception {
    // 获取连接
    connection = configuration.getDataSource().getConnection();
    // 获取sql  select * from user where id = #{id} and username = #{username}
    String sql = mappedStatement.getSql();
    // 解析sql把 #{} 这种标记通过反射，把指定参数值放到指定？位置
    BoundSql boundsql = getBoundSql(sql);
    // 解析后的sql select * from user where id = ? and username = ?
    String resultSql = boundsql.getSqlText();
    // 获取传入的参数类型
    Class<?> paramterType = mappedStatement.getParameterType();
    List<ParameterMapping> parameterMappingList = boundsql.getParameterMappingList();
    PreparedStatement preparedStatement = connection.prepareStatement(resultSql);
    for (int i = 0; i < parameterMappingList.size(); i++) {
      ParameterMapping parameterMapping = parameterMappingList.get(i);
      String name = parameterMapping.getContent();
      Field field = paramterType.getDeclaredField(name);
      field.setAccessible(true);
      // 获取参数值
      Object paramVal = field.get(param[0]);
      preparedStatement.setObject(i + 1, paramVal);
    }
    preparedStatement.execute();
  }

  public void insert(Configuration configuration, MappedStatement mappedStatement, Object[] param)
      throws Exception {
    // 获取连接
    connection = configuration.getDataSource().getConnection();
    // 获取sql  select * from user where id = #{id} and username = #{username}
    String sql = mappedStatement.getSql();
    // 解析sql把 #{} 这种标记通过反射，把指定参数值放到指定？位置
    BoundSql boundsql = getBoundSql(sql);
    // 解析后的sql select * from user where id = ? and username = ?
    String resultSql = boundsql.getSqlText();
    // 获取传入的参数类型
    Class<?> paramterType = mappedStatement.getParameterType();
    List<ParameterMapping> parameterMappingList = boundsql.getParameterMappingList();
    PreparedStatement preparedStatement = connection.prepareStatement(resultSql);
    for (int i = 0; i < parameterMappingList.size(); i++) {
      ParameterMapping parameterMapping = parameterMappingList.get(i);
      String name = parameterMapping.getContent();
      Field field = paramterType.getDeclaredField(name);
      field.setAccessible(true);
      // 获取参数值
      Object paramVal = field.get(param[0]);
      preparedStatement.setObject(i + 1, paramVal);
    }
    System.out.println(preparedStatement.toString());
    preparedStatement.execute();
  }

  public void update(Configuration configuration, MappedStatement mappedStatement, Object[] param)
      throws Exception {
    // 获取连接
    connection = configuration.getDataSource().getConnection();
    // 获取sql  select * from user where id = #{id} and username = #{username}
    String sql = mappedStatement.getSql();
    // 解析sql把 #{} 这种标记通过反射，把指定参数值放到指定？位置
    BoundSql boundsql = getBoundSql(sql);
    // 解析后的sql select * from user where id = ? and username = ?
    String resultSql = boundsql.getSqlText();
    // 获取传入的参数类型
    Class<?> paramterType = mappedStatement.getParameterType();
    List<ParameterMapping> parameterMappingList = boundsql.getParameterMappingList();
    PreparedStatement preparedStatement = connection.prepareStatement(resultSql);
    for (int i = 0; i < parameterMappingList.size(); i++) {
      ParameterMapping parameterMapping = parameterMappingList.get(i);
      String name = parameterMapping.getContent();
      Field field = paramterType.getDeclaredField(name);
      field.setAccessible(true);
      // 获取参数值
      Object paramVal = field.get(param[0]);
      preparedStatement.setObject(i + 1, paramVal);
    }
    preparedStatement.execute();
  }

  private BoundSql getBoundSql(String sql) {

    ParameterMappingTokenHandler parameterMappingTokenHandler = new ParameterMappingTokenHandler();
    GenericTokenParser genericTokenParser =
        new GenericTokenParser("#{", "}", parameterMappingTokenHandler);
    String parse = genericTokenParser.parse(sql);
    List<ParameterMapping> parameterMappings = parameterMappingTokenHandler.getParameterMappings();
    BoundSql boundSql = new BoundSql(parse, parameterMappings);
    return boundSql;
  }

  public void close() throws SQLException {}
}
