package com.executor;

import com.config.Configuration;
import com.config.MappedStatement;

import java.sql.SQLException;
import java.util.List;

/**
 * @author aleng
 * @version 1.0.0
 * @className Executor
 * @description TODO
 * @createTime 2020年04月24日 17:57:00
 */
public interface Executor {

  <E> List<E> query(Configuration configuration, MappedStatement mappedStatement, Object[] param)
      throws Exception;

  void delete(Configuration configuration, MappedStatement mappedStatement, Object[] param)
      throws Exception;

  void update(Configuration configuration, MappedStatement mappedStatement, Object[] param)
      throws Exception;

  void insert(Configuration configuration, MappedStatement mappedStatement, Object[] param)
      throws Exception;

  void close() throws SQLException;
}
