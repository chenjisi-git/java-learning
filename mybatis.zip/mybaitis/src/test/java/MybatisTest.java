import com.builder.SqlSessionFactoryBuilder;
import com.dao.IUserDao;
import com.entity.User;
import com.factory.SqlSessionFactory;
import com.io.Resource;
import com.session.SqlSession;
import org.junit.Test;

import java.io.InputStream;
import java.util.List;

/**
 * @author aleng
 * @version 1.0.0
 * @className MybatisTest
 * @description TODO
 * @createTime 2020年04月23日 14:14:00
 */
public class MybatisTest {

  @Test
  public void test() throws Exception {
    InputStream inputStream = Resource.getResourceAsStream("sqlMapConfig.xml");
    SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
    SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBuilder.create(inputStream);
    SqlSession sqlSession = sqlSessionFactory.openSession();
    List<User> userList = sqlSession.selectList("com.dao.IUserDao.getUserList");
    for (User user : userList) {
      System.out.println(user);
    }

    IUserDao userDao = sqlSession.getMappper(IUserDao.class);
    Long userId = 10L;
    User user = new User();
    user.setId(userId);
    user.setName("张三");
    System.out.println(userDao.getUserByName(user));
    // 新增
    userDao.saveUser(user);
    // 修改
    user.setName("test1");
    userDao.updateById(user);
    // 查询
    userList = userDao.getUserList();
    for (User temp : userList) {
      System.out.println(temp);
    }
    // 删除
    userDao.deleteById(user);
  }
}
