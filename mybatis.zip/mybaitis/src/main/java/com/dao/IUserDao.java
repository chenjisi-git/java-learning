package com.dao;

import com.entity.User;

import java.util.List;

/**
 * @author cjs
 * @version 1.0.0
 * @className IUserDao
 * @description TODO
 * @createTime 2020年04月30日 23:59:00
 */
public interface IUserDao {

  List<User> getUserList();

  User getUserByName(User user);

  void deleteById(User user);

  void updateById(User user);

  void saveUser(User user);
}
